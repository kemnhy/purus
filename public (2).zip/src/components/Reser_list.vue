<template>
  <div class="reser_list">
    예약내역 목록
  </div>
</template>

<script setup>
</script>

<style scoped lang="scss">
</style>