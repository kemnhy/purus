<template>
  <div>
    <div>
      <!-- 헤더영역 -->
      <Header_w lineColor="#092857" />
      <!-- 견적확인 -->
      <div class="esti_check esti_inner">
        <div class="esti_wrap">
          <!-- 영역 이름 -->
          <div class="esti_title">
            <router-link to="/estimate"><i class="fa-solid fa-arrow-left"></i></router-link>
            <p>예약하기</p>
            <p></p>
          </div>
          <!-- 게이지 -->
          <div class="esti_gauge">
            <span></span>
          </div>
          <!-- 주소 입력 -->
          <div class="addr">
            <p>
              서비스 받으실 주소를 입력해주세요.
              <span>(필수)</span>
            </p>
            <div class="form-group">
              <label for="address">주소</label>
              <div class="input-with-button">
                <input
                  type="text"
                  id="address"
                  v-model="address"
                  placeholder="주소를 입력하세요"
                  required />
                <button type="button" @click="handleAddressSearch" class="search-btn">
                  주소검색
                </button>
              </div>
            </div>
            <div class="form-group">
              <label for="detailAddress">상세주소</label>
              <input
                type="text"
                id="detailAddress"
                v-model="detailAddress"
                placeholder="상세주소를 입력하세요"
                required />
            </div>
          </div>
          <div class="service_date">
            <p>
              희망 서비스 날짜를 선택해주세요.
              <span>(필수)</span>
            </p>
          </div>
          <div class="calendar">
            <!-- 달력 헤더 -->
            <div class="calendar-header">
              <button class="" @click="prevMonth">◀</button>
              <span>{{ currentYear }}년 {{ currentMonth + 1 }}월</span>
              <button class="" @click="nextMonth">▶</button>
            </div>

            <!-- 요일 -->
            <div class="calendar-weekdays">
              <span
                v-for="day in weekDays"
                :key="day"
                :class="{ sun: day === '일', sat: day === '토' }">
                {{ day }}
              </span>
            </div>

            <!-- 날짜 -->
            <div class="calendar-days">
              <span v-for="blank in blanks" :key="'b' + blank">&nbsp;</span>
              <span
                v-for="date in daysInMonth"
                :key="date"
                :class="{ sun: isSunday(date), sat: isSaturday(date) }">
                {{ date }}
              </span>
            </div>

            <!-- 오전/오후 버튼 -->
            <div class="calendar-period">
              <button @click="period = 'AM'" :class="{ active: period === 'AM' }">오전</button>
              <button @click="period = 'PM'" :class="{ active: period === 'PM' }">오후</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import Header_w from "@/components/Header_w.vue";
import { ref, computed } from "vue";
//카카오 주소 검색기능
const handleAddressSearch = () => {
  new window.daum.Postcode({
    oncomplete: (data) => {
      let addr = "";
      let extraAddr = "";

      // 도로명 주소와 지번 주소 구분
      if (data.userSelectedType === "R") {
        addr = data.roadAddress;
      } else {
        addr = data.jibunAddress;
      }

      // 도로명 주소인 경우 추가 정보 처리
      if (data.userSelectedType === "R") {
        // 동/로 정보가 있는 경우 추가
        if (data.bname !== "" && /[동|로|가]$/g.test(data.bname)) {
          extraAddr += data.bname;
        }
        // 건물명이 있는 경우 추가
        if (data.buildingName !== "" && data.apartment === "Y") {
          extraAddr += extraAddr !== "" ? ", " + data.buildingName : data.buildingName;
        }
        // 추가 정보가 있는 경우 괄호로 묶기
        if (extraAddr !== "") {
          extraAddr = " (" + extraAddr + ")";
        }
        addr += extraAddr;
      }

      // 선택된 주소를 폼 데이터에 설정
      formData.value.address = addr;
    },
  }).open();
};

const today = new Date();
const currentYear = ref(today.getFullYear());
const currentMonth = ref(today.getMonth());
const period = ref("AM");

const weekDays = ["일", "월", "화", "수", "목", "금", "토"];

// 한 달의 날짜 개수
const daysInMonth = computed(() => {
  return Array.from(
    { length: new Date(currentYear.value, currentMonth.value + 1, 0).getDate() },
    (_, i) => i + 1
  );
});

// 1일이 무슨 요일인지
const blanks = computed(() => {
  const firstDay = new Date(currentYear.value, currentMonth.value, 1).getDay();
  return Array.from({ length: firstDay });
});

const prevMonth = () => {
  if (currentMonth.value === 0) {
    currentMonth.value = 11;
    currentYear.value--;
  } else {
    currentMonth.value--;
  }
};

const nextMonth = () => {
  if (currentMonth.value === 11) {
    currentMonth.value = 0;
    currentYear.value++;
  } else {
    currentMonth.value++;
  }
};

const isSunday = (date) => new Date(currentYear.value, currentMonth.value, date).getDay() === 0;
const isSaturday = (date) => new Date(currentYear.value, currentMonth.value, date).getDay() === 6;
</script>

<style scoped lang="scss">
@use "../assets/styles/variables" as *;

.esti_inner {
  max-width: 1000px;
  margin: auto;
  margin-bottom: 50px;
}
// 견적 확인
// 영역 이름
.esti_title {
  display: flex;
  height: 60px;
  // background-color: aliceblue;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid $grey-color;
  margin-bottom: 15px;
  p,
  i {
    font-size: $esti-large-txt;
    font-weight: bold;
    color: $font-color;
  }
}
// 게이지
.esti_gauge {
  position: relative;
  margin-bottom: 30px;
  width: 100%;
  height: 15px;
  border-radius: 10px;
  background-color: $point-color;
  overflow: hidden;
}
.addr,
.service_date {
  p {
    font-size: $medium-txt-2;
    span {
      font-size: 16px;
      color: $point-color;
    }
  }
  input {
    border: 1px solid $border-color;
    border-radius: 8px;
    padding: 10px 8px;
    margin-top: 10px;
    width: 70%;
  }
}
.service_date {
  margin-top: 60px;
}

// 달력
.calendar {
  width: 100%;
  padding: 10px;
}
.calendar-header {
  display: flex;
  margin-bottom: 10px;
  justify-content: center;
}
.calendar-weekdays,
.calendar-days {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  text-align: center;
}
.sun {
  color: red;
}
.sat {
  color: blue;
}
.calendar-period {
  display: flex;
  justify-content: space-around;
  margin-top: 10px;
}
.calendar-period button.active {
  background-color: #092857;
  color: #fff;
}
</style>
